Names: Patrick Maes, Denisha Saviela

No outside sources used, however I did reference java documentation on the case statement just for 
syntax. 